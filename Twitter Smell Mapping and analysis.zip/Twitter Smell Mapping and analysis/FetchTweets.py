from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream
import time
import json
import re

###########################################################################################################################
#...................................................DEFINING ACCESS TOKENS................................................#
###########################################################################################################################

access_token = '977051785021087744-GGi2atLkVhlQj0wxNynpS8wRT834pob'
access_token_secret = 'znw8j7OZSiOLefTh54K3WM9b4PCo3UORqMki04dDjJCGz'
consumer_key = 'uTfATjjlH4AooP0hyszOkyYuR'
consumer_secret = 'bcdDvLSzylvckq2BX5AGCBH6hx1s6PYN9fZoeGye7pVflnDhdE'

class StdOutListener(StreamListener):

    def on_data(self, status):
        print ("fetchingtweets")
        #tweet=re.sub('\\','',status)
        file = open("ajitmandeep.json","a")
        file.write(json.dumps(status) + '\n' )
        return True

    on_event=on_data

    def on_error(self, status):
        print (status)

try:
    l = StdOutListener()
    auth = OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    stream = Stream(auth, l)
    stream.filter(locations=[76.837864,28.407194,77.345982,28.880844])
    #stream.filter(locations=[72.747673,18.884734,73.046364,19.283163]) #Mumbai
    #stream.filter(locations= [-0.56,51.26,0.28,51.68]) #frankfurt
    #time.sleep(3)
except:
    l = StdOutListener()
    auth = OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    stream = Stream(auth, l)
    stream.filter(locations=[76.837864,28.407194,77.345982,28.880844])
    #stream.filter(locations=[72.747673,18.884734,73.046364,19.283163]) #Mumbai
    #stream.filter(locations=[-0.56,51.26,0.28,51.68]) #frankfurt
