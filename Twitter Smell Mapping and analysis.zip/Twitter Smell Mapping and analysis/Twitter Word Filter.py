import re
import string
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt
frequency = {}
document_text = open('ajitmandeep.json', 'r')
text_string = document_text.read().lower()
match_pattern = re.findall(r'\b[a-z]{3,15}\b', text_string)
 
for word in match_pattern:
    count = frequency.get(word,0)
    frequency[word] = count + 1
     
frequency_list = frequency.keys()
#w=["abattoir","abattoirs","almond","almonds","amber","animal","animals","apple pie","apple pies","aromatic","arugula","asian food","asphalt","avocado","avocados","bacon","baked","baked goods","bakery","baklava","baklavas","balsamic","banana","bananas","barbecue","basil","bbq","beer","beers","bin","bins","biscuit","biscuits","bitter","bleach","blooming","blossom","blossoming","blossoms","bread","burnt","buses","bus","cabbage","cabbages","cake","cakes","car","caramel","cardamom","cars","cedar","cedarwood","cheese","cheeses","chemical","chemicals","chicken","chimney","chlorine","chocolate","chocolates","cigar","cigarettes","cigarette","cigars","cinnamon","citrus","cloth","clothes","coal","coals","coffee","coffees","cologne","conifer","cookie","cookies","corn","couscous","crepe","crepes","cucumber","cucumbers","dentist","diesel","dirt","dirty","dirty clothes","dog shit","dogshit","dough","drains","dry flowers","dry grass","dust","dusty","earl grey","earth","earthy","egg","eggs","eggy","eucalyptus","excrement","exhaust","factory","faeces","falafel","fart","farts","fatty","fish","fishy","floral","flowers","flower","flower shop","food","flowery","food market","fragrance","fragrant","french fries","fresh air","fresh bread","fresh coffee","fresh fish","freshly baked","fried","fruit","fruits","fruity","fuel","fume","fumes","garbage","garbage truck","garlic","gasoline","gassy","glue","goat","grease","greasy","ground","gum","hash","hay","herb","herbal","herbs","herring","herrings","honey","horse","hot dog","hotdog","hot-dog","ice cream","icecream","ice-cream","incense","indian food","industrial","iron","ironing","ivy","jasmine","latex","laundry","lavender","leafy","leather","leaves","leek","lemon","lemons","licorice","lily","lilies","lime","limes","linen","litter","lorries","magnolia","manure","marshmallow","marshmallows","mayonnaise","meat","meaty","medicinal","melon","melons","metal","metallic","metro","mince pie","mince pies","misty","mouldy","moussaka","moussakas","mud","muddy","mushroom","mushrooms","musk","mustard","musty","nutty","odor","odors","oil","oily","old wood","omelette","omelettes","onion","onions","orange juice","oriental food","oven","ozone","paint","pancake","pancakes","paraffin","pastries","pastry","pear","pears","pee","pepper","peppermint","perfume","petrol","pine","piss","pizza","pizzas","plant","plants","pot","potato","potatoes","powdery","public toilet","public toilets","putrid","raisin","raisins","resinous","rose","rosemary","rosey","rotten","rotten fruit","rotten fruits","rubber","rubbish","rust","sage","salt","salty","sandalwood","sandwich","sandwiches","sandy","sausage","sausages","scent","seafood","sewage","sewer","sewers","shit","skunk","skunks","smoke","smoker","smokey","smoky","soil","soup","soups","sour","sour milk","spices","spicy","spicy food","spray paint","spring","steak","steaks","steam","stone","stones","strawberries","strawberry","subway","suede","sulphur","sushi","sweat","sweaty","sweet","tabacco","tea","tire","tires","tobacco","toilet","toilets","traffic","tram","trams","trash","tree","trees","tulip","tulips","tyre","urinal","urine","vanilla","vegetable","vegetables","vetiver","vinegar","violet","violets","vomit","wafer","wafers","waffle","waffles","waste","weed","wet leaf","wet leaves","wood","woodlands","woody","zesty","zoo"]
w101=["asphalt","burnt","bus","buses","car","cars","exhaust","lorries","traffic","tram","trams"]
w102=["chemical","chemicals","chlorine","fuel","gasoline","linen","oil","oily","petrol"]
w103=["dust","dusty","fume","fumes","smoke","mouldy"]
w200=["chimney","coal","coals","diesel","drains","factory","industrial","iron","metal","metallic","rust","sewage","sewer","sewers","steam"]
w301=["abattoir","abattoirs","almond","almonds","apple pie","apple pies","arugula","asian food","avocado","avocados","bacon","baked","baked goods","bakery","baklava","baklavas","balsamic","banana","bananas","basil","beer","beers","biscuit","biscuits","bitter","bread","cabbage","cabbages","cake","cakes","caramel","cardamom","cheese","cheeses","chicken","chocolate","chocolates","cinnamon","citrus","coffee","coffees","cookie","cookies","corn","couscous","crepe","crepes","cucumber","cucumbers","dough","earl grey","egg","eggs","eggy","falafel","fatty","fish","fishy","food","food market","french fries","french fry","fresh bread","fresh coffee","fresh fish","freshly baked","fried","fruit","fruits","fruity","garlic","grease","greasy","hash","herring","herrings","honey","hot dog","hotdog","hot-dog","ice cream","icecream","ice-cream","indian food","leek","lemon","lemons","licorice","lime","limes","marshmallow","marshmallows","mayonnaise","meat","meaty","melon","melons","mince pie","mince pies","moussaka","moussakas","mushroom","mushrooms","mustard","omelette","omelettes","onion","onions","orange juice","oriental food","oven","ozone","pancake","pancakes","pastries","pastry","pear","pears","pepper","peppermint","pizza","pizzas","potato","potatoes","raisin","raisins","salt","salty","sandwich","sandwiches","sausage","sausages","seafood","soup","soups","sour milk","spices","spicy","spicy food","steak","steaks","strawberries","strawberry","sushi","sweet","tea","vanilla","vegetable","vegetables","vinegar","wafer","wafers","waffle","waffles","zesty","aromatic"]
w302=["barbecue","bbq"]
w400=["cigar","cigarette","cigarettes","cigars","incense","nutty","smoker","smokey","smoky","tabacco","tobacco","smoke"]
w500=["bleach","cloth","clothes","cologne","dentist","glue","ironing","laundry","paint","resin","spray","paint"]
w600=["latex","leather","rubber","suede","tire","tires","tyre"]
w701=["bin","bins","garbage","garbage truck","litter","rubbish","trash","waste"]
w702=["pee","piss","public toilet","public toilets","toilet","toilets","urinal","urine","vomit"]
w703=["dog shit","dogshit","excrement","faeces","fart","farts","feces","gassy","manure","shit"]
w704=["putrid","rotten","rotten fruit","rotten fruits","sour","mouldy","musty"]
w800=["animal","animals","dirt","dirty","dirty clothes","fresh air","horse","mud","muddy","paraffin","skunk","skunks","sweat","sweaty","vetiver","zoo"]
w901=["blooming","blossom","blossoming","blossoms","floral","flower","flowers","flowershop","flowery","fragrance","fragrant","herb","herbal","herbs","jasmine","lavender","lilies","lily","magnolia","medicinal","musk","odor","odors","perfume","plant","plants","pot","resinous","rosemary","rosey","sage","scent","spring","tulip","tulips","violet","violets","weed","wet","leaf","aromatic"]
w902=["amber","cedar","cedarwood","conifer","dry grass","earth","earthy","eucalyptus","goat","grass","grassy","ground","gum","hay","ivy","leafy","leaves","misty","old wood","pine","powdery","sandalwood","sandy","soil","stone","stones","sulphur","tree","trees","wood","woodlands","woody"]
w1000=["metro","subway"]
'''
attar1=["bela"]
attar2=["rose"]
attar3=["genda"]
attar4=["mehndi"]
attar5=["saffron"]
attar6=["shamama"]
attar7=["mitti"]
attar8=["chai"]
attar9=["jasmine"]
'''



total101=0
for words in w101:
    try:
        print(words,frequency[words])
        total101=total101+frequency[words]
    except:
        continue
print("Frequency of emissions_traffic",total101)

total102=0
for words in w102:
    try:
        print(words,frequency[words])
        total102=total102+frequency[words]
    except:
        continue
print("Frequency of emissions_fuel",total102)

total103=0
for words in w103:
    try:
        print(words,frequency[words])
        total103=total103+frequency[words]
    except:
        continue
print("Frequency of emissions_dust",total103)

total200=0
for words in w200:
    try:
        print(words,frequency[words])
        total200=total200+frequency[words]
    except:
        continue
print("Frequency of industry",total200)

total301=0
for words in w301:
    try:
        print(words,frequency[words])
        total301=total301+frequency[words]
    except:
        continue
print("Frequency of food_food&beverages",total301)

total302=0
for words in w302:
    try:
        print(words,frequency[words])
        total302=total302+frequency[words]
    except:
        continue
print("Frequency of food_bbq",total302)

total400=0
for words in w400:
    try:
        print(words,frequency[words])
        total400=total400+frequency[words]
    except:
        continue
print("Frequency of tobaccosmoke",total400)

total500=0
for words in w500:
    try:
        print(words,frequency[words])
        total500=total500+frequency[words]
    except:
        continue
print("Frequency of cleaning",total500)

total600=0
for words in w600:
    try:
        print(words,frequency[words])
        total600=total600+frequency[words]
    except:
        continue
print("Frequency of synthetic",total600)

total701=0
for words in w701:
    try:
        print(words,frequency[words])
        total701=total701+frequency[words]
    except:
        continue
print("Frequency of waste_garbage",total701)

total702=0
for words in w702:
    try:
        print(words,frequency[words])
        total702=total702+frequency[words]
    except:
        continue
print("Frequency of waste_pee&vomit",total702)

total703=0
for words in w703:
    try:
        print(words,frequency[words])
        total703=total703+frequency[words]
    except:
        continue
print("Frequency of waste_excrement",total703)

total704=0
for words in w704:
    try:
        print(words,frequency[words])
        total704=total704+frequency[words]
    except:
        continue
print("Frequency of waste_rotten",total704)

total800=0
for words in w800:
    try:
        print(words,frequency[words])
        total800=total800+frequency[words]
    except:
        continue
print("Frequency of animals",total800)

total901=0
for words in w901:
    try:
        print(words,frequency[words])
        total901=total901+frequency[words]
    except:
        continue
print("Frequency of nature_flower&plants",total901)

total902=0
for words in w902:
    try:
        print(words,frequency[words])
        total902=total902+frequency[words]
    except:
        continue
print("Frequency of nature_tree&soil",total902)

total1000=0
for words in w1000:
    try:
        print(words,frequency[words])
        total1000=total1000+frequency[words]
    except:
        continue
print("Frequency of metro",total1000)

'''
total101=0
for words in attar1:
    try:
        #print(words,frequency[words])
        total101=(total101+frequency[words])
    except:
        continue
print("Frequency of Bela",total101)

total102=0
for words in attar2:
    try:
        #print(words,frequency[words])
        total102=(total102+frequency[words])
    except:
        continue
print("Frequency of Rose",total102)

total103=0
for words in attar3:
    try:
        #print(words,frequency[words])
        total103=(total103+frequency[words])
    except:
        continue
print("Frequency of Genda",total103)

total104=0
for words in attar4:
    try:
        #print(words,frequency[words])
        total104=(total104+frequency[words])
    except:
        continue
print("Frequency of Mehndi",total104)

total105=0
for words in attar5:
    try:
        #print(words,frequency[words])
        total105=(total105+frequency[words])
    except:
        continue
print("Frequency of Zafran",total105)

total106=0
for words in attar1:
    try:
        #print(words,frequency[words])
        total106=(total106+frequency[words])
    except:
        continue
print("Frequency of Shamama",total106)

total107=0
for words in attar7:
    try:
        #print(words,frequency[words])
        total107=(total107+frequency[words])
    except:
        continue
print("Frequency of Mitti",total107)

total108=0
for words in attar8:
    try:
        #print(words,frequency[words])
        total108=(total108+frequency[words])
    except:
        continue
print("Frequency of Chai",total108)

total109=0
for words in attar9:
    try:
        #print(words,frequency[words])
        total109=(total109+frequency[words])
    except:
        continue
print("Frequency of Jasmine",total109)'''
#objects=("bela","rose","genda","mehndi","zafran","shamama","mitti","chai","jasmine")
objects = ("emissions_traffic","emissions_fuel","emissions_dust","industry","food_food&beverages","food_bbq","tobaccosmoke","cleaning","synthetic","waste_garbage","waste_pee&vomit","waste_excrement","waste_rotten","animals","nature_flower&plants","nature_tree&soil","metro")
y_pos = np.arange(len(objects))
#performance=[total101,total102,total103,total104,total105,total106,total107,total108,total109]
performance = [total101,total102,total103,total200,total301,total302,total400,total500,total600,total701,total702,total703,total704,total800,total901,total902,total1000]
 
plt.bar(y_pos, performance, align='center')
plt.xticks(y_pos, objects,rotation='vertical')
plt.ylabel('Count')
plt.title('Smell Dictionary')
 
plt.show()
    
#for words in w:
    #if words==w:
    #if words==['the']:
        #for words in w:
    #w=["car","bus"]
    #for w in words:
    #if words=="asphalt" or words=="burnt" or words=="bus" or words=="buses" or words=="car" or words=="cars" or words=="exhaust" or words=="traffic" or words=="tram" or words=="trams":
    
    #try:
       # print (words, frequency[words])
    #except:
       # continue
    

